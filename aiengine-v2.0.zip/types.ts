
export enum ViewMode {
  LANDING = 'LANDING',
  DASHBOARD = 'DASHBOARD'
}

export enum DashboardTool {
  CHAT = 'CHAT',
  IMAGE = 'IMAGE',
  ANALYTICS = 'ANALYTICS',
  SETTINGS = 'SETTINGS'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
}
