
import React, { useState } from 'react';
import { ViewMode } from './types';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';

const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>(ViewMode.LANDING);

  const handleGetStarted = () => {
    setViewMode(ViewMode.DASHBOARD);
  };

  const handleBackToLanding = () => {
    setViewMode(ViewMode.LANDING);
  };

  return (
    <div className="w-full min-h-screen">
      {viewMode === ViewMode.LANDING ? (
        <LandingPage onGetStarted={handleGetStarted} />
      ) : (
        <Dashboard onBack={handleBackToLanding} />
      )}
    </div>
  );
};

export default App;
