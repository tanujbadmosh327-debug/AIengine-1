
import React, { useEffect, useState } from 'react';
import { Button } from './Button';

interface LandingPageProps {
  onGetStarted: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      const sections = ['features', 'solutions', 'pricing', 'resources'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top >= 0 && rect.top <= window.innerHeight / 2) {
            setActiveSection(section);
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="bg-background-dark min-h-screen">
      {/* Background Gradients */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-primary/10 blur-[150px] animate-pulse-glow"></div>
        <div className="absolute bottom-[10%] right-[-10%] w-[40%] h-[60%] bg-secondary/10 blur-[150px] animate-pulse-glow" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-[1000] transition-all duration-500 ${scrolled ? 'py-4 glass border-b border-white/5' : 'py-8'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2.5 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="bg-primary p-2 rounded-xl group-hover:rotate-12 transition-transform shadow-[0_0_15px_rgba(37,209,244,0.4)]">
              <span className="material-symbols-outlined text-background-dark text-2xl font-bold">hub</span>
            </div>
            <span className="text-2xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">AIEngine</span>
          </div>

          <div className="hidden lg:flex items-center gap-10 bg-white/5 px-8 py-2.5 rounded-full border border-white/10 backdrop-blur-xl">
            {['features', 'solutions', 'pricing', 'resources'].map((item) => (
              <a 
                key={item}
                href={`#${item}`}
                onClick={(e) => scrollToSection(e, item)}
                className={`text-sm font-bold uppercase tracking-[0.15em] transition-all hover:text-primary ${activeSection === item ? 'text-primary' : 'text-slate-400'}`}
              >
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-5">
            <button className="hidden sm:block text-xs font-bold uppercase tracking-widest text-slate-400 hover:text-white transition-colors">Log In</button>
            <Button onClick={onGetStarted} variant="primary" size="sm" className="rounded-full shadow-primary/20">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-32 min-h-screen flex items-center overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="relative z-10 space-y-8">
            <div className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full glass border border-primary/20 bg-primary/5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              <span className="text-xs font-black uppercase tracking-[0.2em] text-primary">Intelligence v2.4 Launch</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-black leading-[0.95] tracking-tighter">
              Next-Gen <br /> 
              <span className="text-gradient">Autonomy</span> <br />
              <span className="text-slate-100/50">Redefined.</span>
            </h1>
            
            <p className="text-xl text-slate-400 max-w-xl leading-relaxed font-medium">
              AIEngine builds autonomous intelligence layers for the world's most ambitious companies. Scale operations 10x with zero friction.
            </p>

            <div className="flex flex-wrap gap-5">
              <Button onClick={onGetStarted} size="lg" className="group shadow-2xl">
                Start Deploying
                <span className="material-symbols-outlined ml-2 group-hover:translate-x-1 transition-transform">arrow_forward</span>
              </Button>
              <Button variant="glass" size="lg" className="border-white/5">
                Watch the Core
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-8 opacity-50">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map((i) => (
                  <img key={i} src={`https://i.pravatar.cc/100?img=${i+10}`} className="w-10 h-10 rounded-full border-2 border-background-dark shadow-xl" alt="user" />
                ))}
              </div>
              <p className="text-xs font-bold uppercase tracking-widest">+2.5k Teams Joined Today</p>
            </div>
          </div>

          <div className="relative hidden lg:block perspective-dashboard">
            <div className="absolute inset-0 bg-primary/20 blur-[100px] rounded-full scale-150 animate-pulse-glow"></div>
            <div className="glass p-3 rounded-[2.5rem] border border-white/10 relative z-10 bg-slate-900/40 shadow-2xl overflow-hidden animate-float">
              <div className="bg-slate-950 rounded-[2rem] p-6 h-[500px] flex flex-col gap-6">
                <div className="flex justify-between items-center pb-4 border-b border-white/5">
                   <div className="flex gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                      <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                   </div>
                   <div className="px-3 py-1 bg-white/5 rounded-full text-[10px] font-bold text-slate-500">neural_core_v2.log</div>
                </div>
                <div className="flex-grow space-y-4 font-mono text-xs text-primary/70">
                   <p className="flex items-center gap-2"><span className="text-slate-500">01:42:04</span> [CORE] Initializing transformer layers...</p>
                   <p className="flex items-center gap-2"><span className="text-slate-500">01:42:05</span> [CORE] Connection established to Gemini-3-Pro.</p>
                   <div className="h-2 bg-white/5 rounded-full w-3/4"></div>
                   <div className="h-2 bg-white/5 rounded-full w-1/2"></div>
                   <p className="flex items-center gap-2"><span className="text-slate-500">01:42:08</span> [SUCCESS] Autonomous reasoning active.</p>
                   <div className="mt-8 grid grid-cols-2 gap-4">
                      <div className="glass p-4 rounded-xl border-white/5">
                         <p className="text-[10px] text-slate-500 uppercase font-bold">Active Threads</p>
                         <p className="text-2xl font-bold text-white">4,812</p>
                      </div>
                      <div className="glass p-4 rounded-xl border-white/5">
                         <p className="text-[10px] text-slate-500 uppercase font-bold">Latency</p>
                         <p className="text-2xl font-bold text-primary">12ms</p>
                      </div>
                   </div>
                   <div className="mt-4 flex justify-center">
                      <div className="w-32 h-32 rounded-full border-4 border-dashed border-primary/20 animate-spin-slow flex items-center justify-center">
                        <div className="w-24 h-24 rounded-full border-4 border-primary/40 animate-pulse"></div>
                      </div>
                   </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-y border-white/5 bg-slate-950/30">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
          {[
            { value: '99.9%', label: 'Uptime Reliability', prefix: '' },
            { value: '1.2B', label: 'Inferences/Day', prefix: '' },
            { value: '12ms', label: 'Avg. Latency', prefix: '' },
            { value: '10M+', label: 'Tokens Processed', prefix: '' }
          ].map((stat, i) => (
            <div key={i} className="space-y-2 group">
              <h4 className="text-4xl md:text-5xl font-black text-white group-hover:text-primary transition-colors">{stat.value}</h4>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500">{stat.label}</p>
              <div className="w-8 h-1 bg-primary/20 mx-auto rounded-full group-hover:w-16 transition-all duration-500"></div>
            </div>
          ))}
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-24 space-y-4">
            <h2 className="text-primary font-black text-sm tracking-[0.3em] uppercase">Architecture</h2>
            <h3 className="text-4xl md:text-6xl font-bold tracking-tighter">Engineered for Perfection.</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: 'cognition', title: 'Self-Evolving Core', desc: 'Our neural networks recalibrate in real-time based on incoming data streams for peak performance.' },
              { icon: 'shield_with_heart', title: 'Fortified Security', desc: 'Zero-knowledge encryption layer ensures your sensitive enterprise data never leaks beyond its silo.' },
              { icon: 'speed', title: 'Quantum Latency', desc: 'Sub-15ms response times across 128 global edge regions, delivering speed that feels local everywhere.' },
              { icon: 'token', title: 'Dynamic Scaling', desc: 'Instantly provision additional compute power as your demand spikes without manual configuration.' },
              { icon: 'precision_manufacturing', title: 'Auto-Ops', desc: 'Self-healing infrastructure that predicts and mitigates downtime before it occurs.' },
              { icon: 'alt_route', title: 'Multi-Modal Mesh', desc: 'Seamlessly switch between text, vision, and voice modalities within a single unified API request.' }
            ].map((feature, i) => (
              <div key={i} className="glass-card glass p-10 rounded-[2.5rem] border border-white/5 transition-all duration-500 group relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 blur-[50px] -z-10 group-hover:bg-primary/10"></div>
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center text-primary mb-8 border border-white/10 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(37,209,244,0.1)]">
                  <span className="material-symbols-outlined text-4xl">{feature.icon}</span>
                </div>
                <h4 className="text-2xl font-bold mb-4 tracking-tight group-hover:text-white">{feature.title}</h4>
                <p className="text-slate-400 leading-relaxed text-sm font-medium">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Solutions / 3D Layout */}
      <section id="solutions" className="py-32 bg-slate-950/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div className="order-2 lg:order-1 relative">
                <div className="absolute -inset-10 bg-secondary/10 blur-[100px] rounded-full animate-pulse"></div>
                <div className="glass p-1 rounded-3xl border border-white/5 rotate-[-5deg] hover:rotate-0 transition-transform duration-700 shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80&w=800&h=600" 
                      className="rounded-[1.25rem] w-full h-auto object-cover opacity-80" 
                      alt="3D visualization" 
                    />
                </div>
            </div>
            <div className="order-1 lg:order-2 space-y-8">
              <h2 className="text-secondary font-black text-sm tracking-[0.3em] uppercase">Industry Focus</h2>
              <h3 className="text-5xl font-bold tracking-tighter">Custom Workflows for Elite Teams.</h3>
              <p className="text-slate-400 text-lg leading-relaxed">We don't just provide a tool; we provide a foundation for your digital sovereignty. From FinTech to Space-Tech, our engine adapts.</p>
              
              <div className="space-y-4">
                {[
                  { title: 'Hyper-Growth Scale', desc: 'Support millions of concurrent users with elastic resource mesh.' },
                  { title: 'Legacy Bridge', desc: 'Integrate modern AI with 20-year-old COBOL systems seamlessly.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-5 p-6 rounded-2xl hover:bg-white/5 transition-all border border-transparent hover:border-white/10 group">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center mt-1 group-hover:scale-110 transition-transform">
                      <span className="material-symbols-outlined text-secondary text-sm">auto_fix</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-lg mb-1">{item.title}</h4>
                      <p className="text-sm text-slate-500 font-medium">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-24">
            <h3 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6">Built for every scale.</h3>
            <p className="text-slate-500 max-w-xl mx-auto font-medium">Predictable pricing with no hidden tokens or surprise bills.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { tier: 'Spark', price: '$49', desc: 'For early stage builders.', features: ['1M Monthly Tokens', 'Standard Support', 'Core API Access'] },
              { tier: 'Ignition', price: '$299', desc: 'For high-frequency teams.', features: ['Unlimited Tokens', 'Priority Edge Access', 'Custom Fine-tuning', 'Dedicated Slack Channel'], popular: true },
              { tier: 'Supernova', price: 'Custom', desc: 'For global enterprises.', features: ['Air-gapped Deployment', 'Unlimited Agents', 'Whitelist IP Support', 'On-site Training'] }
            ].map((tier, i) => (
              <div key={tier.tier} className={`glass p-12 rounded-[3rem] border transition-all duration-500 relative flex flex-col ${tier.popular ? 'border-primary/50 shadow-[0_0_50px_rgba(37,209,244,0.15)] scale-105 z-10' : 'border-white/5 opacity-80 hover:opacity-100 hover:scale-102'}`}>
                {tier.popular && <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-6 py-2 bg-primary rounded-full text-background-dark text-xs font-black uppercase tracking-widest shadow-xl">Recommended</div>}
                <div className="mb-10">
                  <h4 className="text-2xl font-bold mb-2 tracking-tight">{tier.tier}</h4>
                  <p className="text-sm text-slate-500 font-medium">{tier.desc}</p>
                </div>
                <div className="mb-12">
                  <span className="text-5xl font-black">{tier.price}</span>
                  {tier.price !== 'Custom' && <span className="text-slate-500 text-lg ml-2">/mo</span>}
                </div>
                <ul className="space-y-5 mb-12 flex-grow">
                  {tier.features.map((feat, idx) => (
                    <li key={idx} className="flex items-center gap-4 text-sm text-slate-300 font-medium">
                      <span className="material-symbols-outlined text-primary text-xl">done_all</span> {feat}
                    </li>
                  ))}
                </ul>
                <Button 
                  variant={tier.popular ? 'primary' : 'glass'} 
                  onClick={onGetStarted}
                  className="w-full py-5 rounded-2xl font-black uppercase tracking-widest"
                >
                  {tier.price === 'Custom' ? 'Talk to Core Team' : 'Get Started Now'}
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 bg-slate-950/20 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
           <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
              <h3 className="text-4xl font-bold tracking-tighter">Trusted by the <span className="text-gradient">Innovators.</span></h3>
              <p className="text-slate-500 font-medium">Leading teams around the globe trust AIEngine to power their mission-critical infrastructure.</p>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { name: 'Elena Vance', role: 'CTO, Lumina Systems', text: '“AIEngine didn’t just speed up our workflow, it changed how we think about automation entirely.”' },
                { name: 'Markus Aris', role: 'Founding Engineer, Nexa', text: '“The latency is unbelievable. We moved from 200ms to 12ms overnight. Best investment of 2024.”' },
                { name: 'Sasha Grey', role: 'Lead AI, OrbitX', text: '“Enterprise security was our biggest hurdle. AIEngine made it their priority, and the results show.”' }
              ].map((t, i) => (
                <div key={i} className="glass p-10 rounded-[2rem] border-white/5 hover:border-white/10 transition-all group">
                   <div className="flex gap-1 mb-6">
                      {[1,2,3,4,5].map(s => <span key={s} className="material-symbols-outlined text-primary text-sm">star</span>)}
                   </div>
                   <p className="text-lg font-medium text-slate-300 mb-8 italic">{t.text}</p>
                   <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/20 p-0.5 border border-primary/20">
                        <img src={`https://i.pravatar.cc/100?img=${i+25}`} className="w-full h-full rounded-full object-cover" alt={t.name} />
                      </div>
                      <div>
                         <p className="font-bold text-white leading-none mb-1">{t.name}</p>
                         <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">{t.role}</p>
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* Resources / Footer */}
      <section id="resources" className="pt-32 pb-20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-6">
          <div className="glass p-16 rounded-[4rem] border-white/10 text-center space-y-8 mb-32 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-secondary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
            <h3 className="text-5xl md:text-7xl font-black tracking-tighter relative z-10">Ready for <span className="text-gradient">Takeoff?</span></h3>
            <p className="text-slate-400 text-xl max-w-xl mx-auto font-medium relative z-10">Deploy your first neural agent in under 120 seconds. Join the elite elite 1% of autonomous teams.</p>
            <div className="flex justify-center gap-5 relative z-10 pt-4">
               <Button onClick={onGetStarted} size="lg" className="px-12 py-5 text-lg">Initialize Core</Button>
            </div>
          </div>

          <footer className="grid grid-cols-1 md:grid-cols-4 gap-20 text-slate-500">
            <div className="col-span-1 md:col-span-2 space-y-8">
               <div className="flex items-center gap-2.5">
                  <div className="bg-primary p-1 rounded-lg">
                    <span className="material-symbols-outlined text-background-dark text-xl font-bold">hub</span>
                  </div>
                  <span className="text-xl font-black tracking-tighter text-white">AIEngine</span>
               </div>
               <p className="max-w-sm text-sm leading-relaxed font-medium">Building the next generation of autonomous infrastructure for the $10T AI economy.</p>
               <div className="flex gap-6">
                  {['twitter', 'github', 'discord', 'linkedin'].map(social => (
                    <span key={social} className="material-symbols-outlined hover:text-primary transition-colors cursor-pointer">{social}</span>
                  ))}
               </div>
            </div>
            <div className="space-y-6">
               <h5 className="text-white font-black text-xs uppercase tracking-[0.2em]">Platform</h5>
               <ul className="space-y-4 text-sm font-medium">
                  <li><a href="#" className="hover:text-primary transition-colors">Documentation</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">API Reference</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">Status</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">Security</a></li>
               </ul>
            </div>
            <div className="space-y-6">
               <h5 className="text-white font-black text-xs uppercase tracking-[0.2em]">Company</h5>
               <ul className="space-y-4 text-sm font-medium">
                  <li><a href="#" className="hover:text-primary transition-colors">About</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">Blog</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">Careers</a></li>
                  <li><a href="#" className="hover:text-primary transition-colors">Brand Assets</a></li>
               </ul>
            </div>
          </footer>
          <div className="mt-20 pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-5">
             <p className="text-[10px] font-bold uppercase tracking-widest">© 2024 AIEngine Core. All rights reserved.</p>
             <div className="flex gap-8 text-[10px] font-bold uppercase tracking-widest">
                <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
                <a href="#" className="hover:text-white transition-colors">Compliance</a>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};
