
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'glass' | 'ghost' | 'glow';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  isLoading, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "relative inline-flex items-center justify-center font-bold tracking-tight transition-all duration-300 transform active:scale-95 disabled:opacity-50 disabled:pointer-events-none";
  
  const variants = {
    primary: "bg-primary text-background-dark shadow-[0_0_20px_rgba(37,209,244,0.3)] hover:shadow-[0_0_30px_rgba(37,209,244,0.5)] hover:-translate-y-1",
    secondary: "bg-secondary text-white shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:shadow-[0_0_30px_rgba(168,85,247,0.5)] hover:-translate-y-1",
    glass: "glass border-white/10 text-white hover:bg-white/10 hover:border-white/20",
    ghost: "text-slate-400 hover:text-primary transition-colors",
    glow: "bg-transparent border border-primary/50 text-primary shadow-[inset_0_0_10px_rgba(37,209,244,0.2)] hover:bg-primary/5 hover:shadow-[inset_0_0_20px_rgba(37,209,244,0.4)]"
  };

  const sizes = {
    sm: "px-5 py-2 text-xs rounded-lg",
    md: "px-7 py-3 text-sm rounded-xl",
    lg: "px-10 py-4 text-base rounded-2xl"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={isLoading}
      {...props}
    >
      {isLoading ? (
        <span className="w-5 h-5 border-2 border-t-transparent border-current rounded-full animate-spin mr-3" />
      ) : null}
      <span className="relative z-10">{children}</span>
    </button>
  );
};
