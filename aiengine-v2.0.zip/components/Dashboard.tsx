
import React, { useState } from 'react';
import { DashboardTool } from '../types';
import { AiChat } from './AiChat';
import { AiImageGen } from './AiImageGen';

interface DashboardProps {
  onBack: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onBack }) => {
  const [activeTool, setActiveTool] = useState<DashboardTool>(DashboardTool.CHAT);

  const sidebarItems = [
    { id: DashboardTool.CHAT, icon: 'forum', label: 'Neural Chat' },
    { id: DashboardTool.IMAGE, icon: 'burst_mode', label: 'Vision Gen' },
    { id: DashboardTool.ANALYTICS, icon: 'query_stats', label: 'Engine Insights' },
    { id: DashboardTool.SETTINGS, icon: 'settings', label: 'Config' },
  ];

  return (
    <div className="flex h-screen bg-background-dark text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 md:w-64 glass-dark border-r border-white/5 flex flex-col">
        <div className="p-6 flex items-center gap-3 mb-8 cursor-pointer" onClick={onBack}>
          <div className="bg-primary p-1.5 rounded-lg">
            <span className="material-symbols-outlined text-background-dark text-2xl font-bold">bubble_chart</span>
          </div>
          <span className="text-xl font-bold tracking-tight hidden md:block">AIEngine</span>
        </div>

        <nav className="flex-grow px-4 space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTool(item.id)}
              className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all ${
                activeTool === item.id 
                  ? 'bg-primary/10 text-primary border border-primary/20' 
                  : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
              }`}
            >
              <span className="material-symbols-outlined">{item.icon}</span>
              <span className="font-semibold text-sm hidden md:block">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
           <div className="glass p-4 rounded-2xl hidden md:block">
              <p className="text-[10px] font-bold text-primary uppercase tracking-[0.2em] mb-2">Enterprise Plan</p>
              <div className="flex justify-between text-xs mb-2">
                <span>Usage</span>
                <span>84%</span>
              </div>
              <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-primary w-[84%]"></div>
              </div>
           </div>
           <button onClick={onBack} className="w-full mt-4 flex items-center justify-center gap-2 p-3 text-slate-500 hover:text-white transition-colors">
              <span className="material-symbols-outlined text-sm">logout</span>
              <span className="text-xs font-bold hidden md:block">Exit Workspace</span>
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow overflow-y-auto relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 blur-[150px] -z-10 rounded-full"></div>
        <div className="max-w-6xl mx-auto p-6 md:p-12 h-full">
          {activeTool === DashboardTool.CHAT && <AiChat />}
          {activeTool === DashboardTool.IMAGE && <AiImageGen />}
          {(activeTool === DashboardTool.ANALYTICS || activeTool === DashboardTool.SETTINGS) && (
             <div className="flex items-center justify-center h-full text-slate-500 flex-col gap-4 opacity-50">
               <span className="material-symbols-outlined text-6xl">construction</span>
               <p className="font-bold">Module Under Optimization</p>
               <p className="text-sm">This feature is being fine-tuned for the v2.1 deployment.</p>
             </div>
          )}
        </div>
      </main>
    </div>
  );
};
