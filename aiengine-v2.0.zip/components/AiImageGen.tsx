
import React, { useState } from 'react';
import { generateImage } from '../services/geminiService';
import { GeneratedImage } from '../types';
import { Button } from './Button';

export const AiImageGen: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [images, setImages] = useState<GeneratedImage[]>([]);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const url = await generateImage(prompt);
      if (url) {
        const newImg: GeneratedImage = {
          id: Date.now().toString(),
          url,
          prompt,
          timestamp: Date.now(),
        };
        setImages(prev => [newImg, ...prev]);
      }
    } catch (error) {
      console.error(error);
      alert("Failed to generate image.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="glass p-8 rounded-3xl space-y-6 border border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <div>
          <h3 className="text-2xl font-black mb-2">Vision Engine</h3>
          <p className="text-slate-400 text-sm">Transform textual concepts into high-fidelity neural representations.</p>
        </div>
        
        <div className="space-y-4">
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A futuristic cybernetic city with neon lights, 8k resolution, cinematic lighting..."
              className="w-full bg-background-dark border border-white/10 rounded-2xl px-5 py-6 text-sm focus:ring-2 focus:ring-primary focus:outline-none min-h-[120px]"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex gap-4">
               <div className="flex items-center gap-2 px-3 py-1.5 glass rounded-lg text-[10px] font-bold uppercase text-slate-400">
                  <span className="material-symbols-outlined text-sm">aspect_ratio</span> 1:1
               </div>
               <div className="flex items-center gap-2 px-3 py-1.5 glass rounded-lg text-[10px] font-bold uppercase text-slate-400">
                  <span className="material-symbols-outlined text-sm">high_quality</span> HD
               </div>
            </div>
            <Button 
              onClick={handleGenerate} 
              isLoading={isGenerating} 
              disabled={!prompt.trim()}
              className="px-10"
            >
              Generate Visuals
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((img) => (
          <div key={img.id} className="group relative overflow-hidden rounded-2xl glass border border-white/10">
            <img src={img.url} alt={img.prompt} className="w-full aspect-square object-cover transition-transform duration-500 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-background-dark via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
              <p className="text-xs text-slate-300 line-clamp-2 mb-4">{img.prompt}</p>
              <div className="flex gap-2">
                <Button variant="glass" size="sm" className="flex-grow">
                  <span className="material-symbols-outlined text-sm mr-2">download</span> Save
                </Button>
                <Button variant="glass" size="sm" className="w-10">
                  <span className="material-symbols-outlined text-sm">share</span>
                </Button>
              </div>
            </div>
          </div>
        ))}
        {!isGenerating && images.length === 0 && (
           <div className="col-span-full py-20 text-center opacity-30">
              <span className="material-symbols-outlined text-6xl mb-4">image_search</span>
              <p className="font-bold">No assets generated yet</p>
           </div>
        )}
      </div>
    </div>
  );
};
